# TikTok Downloader Telegram Bot

Send a TikTok link, get the video back.

## Setup
1. Create a bot with [@BotFather](https://t.me/BotFather) and copy the token.
2. Run locally:
   ```
   pip install -r requirements.txt
   export BOT_TOKEN=your_token
   python bot.py
   ```

## Deploy from GitHub (24/7)
GitHub Actions can't run a bot continuously, so connect your repo to a host:
- **Railway / Render / Fly.io**: New project → Deploy from GitHub repo → it detects the Dockerfile.
- Add environment variable `BOT_TOKEN`.
- Render: choose "Background Worker".

## Notes
- Videos over 50 MB can't be sent by bots.
- TikTok changes often. If downloads break, redeploy to pull the latest `yt-dlp`.
- Only download content you have the right to save.
